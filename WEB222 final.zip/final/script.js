/** Add any JavaScript you need to this file. */

var allProducts = [
    {
        id: 1,
        category: 1,
        name: 'HP ENVY 24- All-in-One PC',
        price: 1379.99,
        description:'conic design transcends all expectations. We crafted the HP ENVY All-in-One with the intention of making a statement. This isn’t just a computer – it’s a work of art. From the artfully inspired stand to the crystal clear Full HD display[1], Quad HD[2] or dazzling 4K screen[3], this computer is worthy of a gallery.',
 
    },
    {
        id: 2,
        category: 1,
        name: 'CYBERPOWERPC Gamer Xtreme VR',
        price: 1764.99,
        description: 'Intel® Core™ Processor i7-9700K GeForce® GTX 1660 SUPER 6GB GDDR5  16GB ADATA XPG Z1 3000MHz RAM  ASUS Prime Z390-P WiFi ATX Motherboard  1TB WD Blue SN550 M.2 PCIe SSD  Avermedia GC570 Live Gamer HD 2 Capture Card  LIAN LI PC-O11 Dynamic ATX Gaming Case',
 
    },
    {
        id: 3,
        category: 1,
        name: 'Apple iMac 27" Retina 5K All-in-One Computer',
        description: 'The all-in-one for all. If you can dream it, you can do it on iMac. It’s beautifully designed, incredibly intuitive and packed with powerful tools that let you take any idea to the next level. And the new 27-inch model elevates the experience in every way, with faster processors and graphics, expanded memory and storage, enhanced audio and video capabilities and an even more stunning Retina 5K display. It’s the desktop that does it all — better and faster than ever.',
        price: 2649.99,
    },
    {
      id: 4,
      category: 1,
      name: 'Microsoft Surface Studio 2 - all-in-one',
      description: 'Surface Studio 2 is the ultimate creative studio, with the same premium design you know and love. Its improved performance handles demanding software that enables you to edit stunning photographs, run circles around renders and create rich 3-D images. Unlock immersive, graphics-rich experiences and put yourself at the center of mixed-reality experiences. Use Surface Studio 2 in Desktop Mode or Studio Mode in a modern executive office or easily transform it into a digital drafting table.',
      price: 6674.99,
    },
    {
        id: 5,
        category: 1,
        name: 'Inspiron Desktop All-in-One',
        description: 'Whether its checking email, running multiple apps, or just safekeeping all your digital content, Inspiron desktop delivers on what matters most to you.Featuring the latest 10th Gen Intel® Core™ processor, zip through tasks quickly and easily. Fast DDR4 memory lets you run multiple applications and tabs seamlessly.  Enjoy reliable internet connection from anywhere in the house without the need for cables thanks to 802.11ac or optional 802.11ax wireless technology.  Give your games extra punch by adding the latest NVIDIA graphics card.',
        price:  1429.99,
    },
    {
        id: 6,
        category: 2,
        name: 'MacBook Pro',
        description: 'Designed for those who defy limits and change the world, the new MacBook Pro is by far the most powerful notebook we’ve ever made. With an immersive 16-inch Retina display, superfast processors, next-generation graphics, the largest battery capacity ever in a MacBook Pro, a new Magic Keyboard and massive storage, it’s the ultimate pro notebook for the ultimate user.',
        price: 2999.00,
    },
    {
        id: 7,
        category: 2,
        name: 'MacBook Air',
        description: 'The incredibly thin and light MacBook Air is now more powerful than ever. It features a brilliant Retina display, new Magic Keyboard, Touch ID, processors with up to twice the performance,1 faster graphics and double the storage capacity. The sleek wedge-shaped design is created from 100 percent recycled aluminum, making it the greenest Mac ever.2 And with all-day battery life, our most popular Mac is your perfectly portable, do-it-all notebook.',
        price: 1299.99,
      },
      {
        id: 8,
        category: 2,
        name: 'Dell XPS 13',
        description: 'New 13" laptop designed with precision engineered details, from stunning materials to minimal footprint, with true unrivaled performance and 10th Gen InteI® Core™ processors.',
        price: 1449.99,
      },
      {
        id: 9,
        category: 2,
        name: 'Microsoft Surface Laptop 3 13.5',
        description: 'Make a powerful statement and fuel your ideas with new Surface Laptop 3. Sleek and light, with improved speed, performance, typing comfort, and battery life, it travels with ease and makes every day more productive. Now in a choice of two sizes, two elegant keyboard finishes, and new colours to match your style. 13.5-inch PixelSense Display, 128 GB Solid State Drive storage, Quad-core 10th Gen Intel Core i5-1035G7 Processor, Windows 10 Home operating system pre-installed, Ports: USB-C, Surface Connect, USB 3.0 x 1, Omnisonic Speakers with Dolby Audio Premium, Includes password-free Windows Hello sign-in and secure cloud storage with fully-integrated OneDrive, Included in the Box: Microsoft Surface Laptop 3, Power Supply, Quick Start Guide, Safety & Warranty',
        price: 1199.99,
      },
      {
      id: 10,
    category: 2,
    name: 'Galaxy Book S 13.3"',
    description: 'Built with an aluminum chassis in Earthy Gold and Mercury Gray, a 13.3” Full HD touchscreen, and weighing just over 2 pounds, the Galaxy Book S gives you the freedom to take your work with you. Take your Galaxy Book S out the door and dont look back. The 42Wh battery gives you up to 17 hours* of video playback on a single charge. Spend long hours binge watching, drafting reports or writing lecture notes without giving the charger a second thought. Galaxy Book S is ready for all your distance learning needs. Whether you are attending online lectures, researching, downloading materials, uploading homework or doing it all at once, Galaxy Book S helps keep your focus on your studies, even from home.',
    price: 1199.99,
  },
];

function showProducts(category = null){

    var productsToList = [...allProducts];
    if(category != null){
        productsToList = productsToList.filter(function(item) {
            return item.category == category;
        });
    }

    var row = document.getElementById('products');
    var html = '';
    productsToList.forEach(element => {
        html += '<div class="col-lg-4 col-md-6 mb-4">';
        html += '   <div class="card h-100">';
        html += '       <a href="#"><img class="card-img-top" src="img/product'+element.id+'.jpg" alt="'+element.name+'" alt=""></a>';
        html += '       <div class="card-body">';
        html += '           <h4 class="card-title">';
        html += '               <a href="#">'+element.name+'</a>';
        html += '           </h4>';
        html += '           <h5>$'+element.price+'</h5>';
        html += '           <p class="card-text">'+element.description+'</p>';
        html += '       </div>';
        html += '       <div class="card-footer">';
        html += '           <small class="text-muted"><button>Add to Cart</button></small>';
        // <p><button>Add to Cart</button></p>
        html += '      </div>';
        html += '   </div>';
        html += '</div>';
    });
    row.innerHTML = html;
}

function handleRadio(action){
    var order_number = document.getElementById('order_number');
    if (action === "show") {
        order_number.style.display = "block";
    } else {
        order_number.style.display = "none";
    }
    
}
    
    var category_header = document.getElementById('product_category');
    if(category_header){
        category_header.innerHTML = 'Category: All';
        showProducts();

        var food_kit = document.getElementById('desktop');
        food_kit.onclick = function(){
            showProducts(1);
            document.getElementById('product_category').innerHTML = 'Category: Desktop';
            document.getElementById('clear_filters').style.display = "block";
            
        };
        var ready_food = document.getElementById('laptop');
        ready_food.onclick = function(){
            showProducts(2);
            document.getElementById('product_category').innerHTML = 'Category: Laptops';
            document.getElementById('clear_filters').style.display = "block";
        };

        var clear_filter = document.getElementById('clear_filters');
        clear_filter.onclick = function(){
            showProducts();
            document.getElementById('product_category').innerHTML = 'Category: All';
            document.getElementById('clear_filters').style.display = "none";
        };
    }
    function ValidateEmail(inputText)
    {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(inputText.value.match(mailformat))
    {
    document.form1.text1.focus();
    return true;
    }
    else
    {
    alert("You have entered an invalid email address!");
    document.form1.text1.focus();
    return false;
    }
    }